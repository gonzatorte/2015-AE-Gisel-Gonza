Limite de los distintos barrios.

e.g.:

a,b,c,d,e,f

significa que el barrio con NRO_BARRIO=a, limita con los barrios con NRO_BARRIO=b,c,d,e,f.